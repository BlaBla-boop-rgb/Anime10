package dev.animecosmetics;

import net.minecraft.resources.Identifier;

/**
 * Style switch: Ronova (red, the original look) or Furina (water: the same effects in blue).
 *
 * Furina style uses the textures under textures/furina/ (blue versions of every texture, made with the
 * same colour turn as below) and turns all colours the code draws by itself from red to blue.
 * Greys, black and white stay as they are.
 */
public final class Theme {
   /** Hue turn of 205 degrees (red to water blue), luminance-preserving; neutral colours stay neutral. */
   private static final float[][] M = new float[][]{
      {-0.4102F, 1.6652F, -0.2549F},
      {0.3456F, 0.3975F, 0.2569F},
      {0.7386F, 1.0608F, -0.7995F}
   };
   /** A little brighter, since blue looks darker than red at the same luminance. */
   private static final float GAIN = 1.1F;

   private Theme() {
   }

   public static boolean water() {
      return Toggles.get(Toggles.Feature.FURINA_STYLE);
   }

   /** Texture id for the current style: "textures/x.png" or, in Furina style, "textures/furina/x.png". */
   public static Identifier tex(String path) {
      return water() && path.startsWith("textures/") ? AnimeCosmetics.id("textures/furina/" + path.substring(9)) : AnimeCosmetics.id(path);
   }

   private static float ch(int row, float r, float g, float b) {
      float v = (M[row][0] * r + M[row][1] * g + M[row][2] * b) * GAIN;
      return v < 0.0F ? 0.0F : Math.min(v, Math.max(1.0F, Math.max(r, Math.max(g, b))));
   }

   /** Red channel in the current style (the inputs are the Ronova colour). */
   public static float r(float r, float g, float b) {
      return water() ? ch(0, r, g, b) : r;
   }

   public static float g(float r, float g, float b) {
      return water() ? ch(1, r, g, b) : g;
   }

   public static float b(float r, float g, float b) {
      return water() ? ch(2, r, g, b) : b;
   }

   /** 0xRRGGBB in the current style. */
   public static int rgb(int rgb) {
      if (!water()) {
         return rgb;
      } else {
         float r = (rgb >> 16 & 0xFF) / 255.0F;
         float g = (rgb >> 8 & 0xFF) / 255.0F;
         float b = (rgb & 0xFF) / 255.0F;
         return to8(ch(0, r, g, b)) << 16 | to8(ch(1, r, g, b)) << 8 | to8(ch(2, r, g, b));
      }
   }

   /** 0xAARRGGBB in the current style. */
   public static int argb(int argb) {
      return water() ? argb & 0xFF000000 | rgb(argb & 0xFFFFFF) : argb;
   }

   /** NativeImage pixel (0xAABBGGRR) in the current style. */
   public static int abgr(int abgr) {
      if (!water()) {
         return abgr;
      } else {
         int c = rgb((abgr & 0xFF) << 16 | (abgr >> 8 & 0xFF) << 8 | abgr >> 16 & 0xFF);
         return abgr & 0xFF000000 | (c & 0xFF) << 16 | (c >> 8 & 0xFF) << 8 | c >> 16 & 0xFF;
      }
   }

   private static int to8(float v) {
      return Math.max(0, Math.min(255, Math.round(v * 255.0F)));
   }
}
