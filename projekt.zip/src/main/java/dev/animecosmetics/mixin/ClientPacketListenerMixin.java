package dev.animecosmetics.mixin;

import dev.animecosmetics.fx.KillFx;
import dev.animecosmetics.title.TotemFx;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundEntityEventPacket;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Notices when your own totem of undying pops (entity event 35 on yourself) and when players die (event 3). */
@Mixin({ClientPacketListener.class})
public abstract class ClientPacketListenerMixin {
   @Inject(
      method = {"handleEntityEvent"},
      at = {@At("HEAD")}
   )
   private void animecosmetics$totem(ClientboundEntityEventPacket packet, CallbackInfo ci) {
      Minecraft mc = Minecraft.getInstance();
      // the packet first arrives on the network thread and is then handled again on the game thread
      if (mc.isSameThread() && mc.level != null && mc.player != null) {
         byte id = packet.getEventId();
         if (id == 35) {
            Entity e = packet.getEntity(mc.level);
            if (e == mc.player) {
               TotemFx.onTotem(mc);
            }
         } else if (id == 3) {
            // death: needed for other players, whose health the client may not know
            Entity e = packet.getEntity(mc.level);
            if (e != null) {
               KillFx.onDeathEvent(mc, e);
            }
         }
      }
   }

   @Inject(
      method = {"handleEntityEvent"},
      at = {@At("RETURN")}
   )
   private void animecosmetics$totemDone(ClientboundEntityEventPacket packet, CallbackInfo ci) {
      // the vanilla totem sound is played inside handleEntityEvent; after it, sounds play normally again
      TotemFx.endMute();
   }
}
